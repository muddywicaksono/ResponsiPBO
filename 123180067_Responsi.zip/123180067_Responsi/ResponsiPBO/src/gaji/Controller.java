package gaji;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import javax.swing.JTable;

public class Controller {
    Model   model;
    ViewGajiP vGajiP;
    ViewDataP vDataP;
    ViewHome vHomeP;
    ViewInfoP vInformasiP;


    Controller(ViewGajiP vGajiP, Model model){
        this.model = model;
        this.vGajiP = vGajiP;

        vGajiP.btnHitung.addActionListener((ActionEvent e) -> {

        });

        vGajiP.btnSimpan.addActionListener((ActionEvent e) -> {
            if(vGajiP.getid_pegawai().equals("")
                    || vGajiP.getnama().equals("")
                    || vGajiP.getposisi().equals("")
                    || vGajiP.getalamat().equals("")
                    || vGajiP.getno_hp().equals("")
                    || vGajiP.getgaji().equals("")
                    || vGajiP.getjam_lembur().equals("")
                    || vGajiP.gettunjangan().equals("")
                    || vGajiP.getpajak().equals("")
                    || vGajiP.gettotal_gaji().equals("")
            ) {
                JOptionPane.showMessageDialog(null, "Field tdk boleh kosong");
            } else{

                String id_pegawai = vGajiP.getid_pegawai();
                String nama = vGajiP.getnama();
                String posisi = vGajiP.getposisi();
                String alamat = vGajiP.getalamat();
                String no_hp = vGajiP.getno_hp();
                String gaji = vGajiP.getgaji();
                String jam_lembur = vGajiP.getjam_lembur();
                String tunjangan = vGajiP.gettunjangan();
                String pajak = vGajiP.getpajak();
                String total_gaji = vGajiP.gettotal_gaji();

                model.insertPegawai(id_pegawai, nama, posisi, alamat, no_hp, gaji, jam_lembur, tunjangan, pajak, total_gaji);
            }
        });


    }

    Controller(ViewDataP vDataP, Model model ){
        this.vDataP = vDataP;
        this.model = model;

        if(model.getBanyakDataPegawai() != 0){
            String dataPegawai[][] = model.readPegawai();
            vDataP.table.setModel((new JTable(dataPegawai, vDataP.kolom)).getModel());

        } else{
            JOptionPane.showMessageDialog(null, "Data Tidak Ada");
        }
    }

    Controller(ViewHome vHomeP, Model model ){
        this.vHomeP = vHomeP;
        this.model = model;
    }

    Controller(ViewInfoP vInformasiP, Model model ){
        this.vInformasiP = vInformasiP;
        this.model = model;
    }
}
