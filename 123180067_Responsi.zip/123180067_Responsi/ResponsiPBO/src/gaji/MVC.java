package gaji;

public class MVC {
    public void Gaji_P(){
        ViewGajiP GajiP = new ViewGajiP();
        Model model = new Model();
        Controller controller = new Controller(GajiP, model);
    }

    public void Data_P(){
        ViewDataP DataP = new ViewDataP();
        Model model = new Model();
        Controller controller = new Controller(DataP,model);
    }

    public void Home(){
        ViewHome HomeP = new ViewHome();
        Model model = new Model();
        Controller controller = new Controller(HomeP, model);
    }

    public void Informasi_P(){
        ViewInfoP InformasiP = new ViewInfoP();
        Model model = new Model();
        Controller controller = new Controller(InformasiP, model);
    }
}
