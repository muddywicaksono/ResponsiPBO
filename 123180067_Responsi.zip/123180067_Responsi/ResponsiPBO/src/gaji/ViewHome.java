package gaji;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import static javax.swing.JFrame.EXIT_ON_CLOSE;
import javax.swing.JLabel;

public class ViewHome extends JFrame {
    JLabel linfo1 = new JLabel ("Selamat Datang.");
    JLabel linfo2 = new JLabel ("Silahkan Masuk ke menu gaji untuk melakukanperhitungan gaji.");
    JLabel linfo3 = new JLabel ("Jika mengalaminkesulitan, klik menu petunjuk");
    JLabel linfo4 = new JLabel ("APLIKASI PERHITUNGAN GAJI PT. VETERAN JAYA");
    JButton btnHome = new JButton("HOME");
    JButton btnGaji = new JButton("GAJI");
    JButton btnData = new JButton("DATA");
    JButton btnInformasi = new JButton("INFORMASI");
    JButton btnAdmin = new JButton("ADMIN");

    ViewHome(){
        //background
        getContentPane().setBackground(Color.LIGHT_GRAY);

        setSize(600,400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);

        add(linfo1);
        add(linfo2);
        add(linfo3);
        add(linfo4);
        add(btnHome);
        add(btnGaji);
        add(btnData);
        add(btnInformasi);
        add(btnAdmin);

        setVisible(true);
        linfo1.setBounds(160,110,200,20);
        linfo2.setBounds(160,150,600,20);
        linfo3.setBounds(160,200,600,20);
        linfo4.setBounds(160,308,600,30);
        btnHome.setBounds(20,30,100,60);
        btnGaji.setBounds(20,110,100,60);
        btnData.setBounds(20,190,100,60);
        btnInformasi.setBounds(20,270,100,60);
        btnAdmin.setBounds(470,30,100,60);

        btnHome.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MVC mvc = new MVC();
                mvc.Home();
                dispose();
            }
        });

        btnGaji.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MVC mvc = new MVC();
                mvc.Gaji_P();
                dispose();
            }
        });

        btnData.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MVC mvc = new MVC();
                mvc.Data_P();
                dispose();
            }
        });

        btnInformasi.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                MVC mvc = new MVC();
                mvc.Informasi_P();
                dispose();
            }
        });
    }
}
